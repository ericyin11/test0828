#include "bootloader.h"

extern ApplicationTypeDef Appli_state;
FRESULT res;
static FLASH_EraseInitTypeDef EraseInitStruct;

uint8_t RAM_Buffer[RAM_BUFFER_SIZE];
uint32_t APP_Size;
uint32_t FirstSector = 0, NbOfSectors = 0, Address = 0;
uint32_t SectorError = 0;
__IO uint32_t data32 = 0 , MemoryProgramStatus = 0;
uint8_t errorcode;
uint32_t *p;

uint8_t SystemUpdateFlag = 0, state = 0;
uint16_t t = 0;
		
typedef  void (*pFunction)(void);
pFunction Jump_To_Application;
uint32_t JumpAddress;

int fputc(int ch, FILE *f)		//??????? ????
{
	HAL_UART_Transmit(&huart1, (uint8_t *)&ch, 1, 100);
	return ch;
}
uint32_t FLASH_Erase_Write(void)		//FLASH??
{
  uint32_t i = 0;
	
  HAL_FLASH_Unlock();
  FirstSector = GetSector(FLASH_USER_START_ADDR);
  NbOfSectors = GetSector(FLASH_USER_END_ADDR) - FirstSector + 1;
	
  EraseInitStruct.TypeErase = FLASH_TYPEERASE_SECTORS;
  EraseInitStruct.VoltageRange = FLASH_VOLTAGE_RANGE_3;
  EraseInitStruct.Sector = FirstSector;
  EraseInitStruct.NbSectors = NbOfSectors;
	if(HAL_FLASHEx_Erase(&EraseInitStruct, &SectorError) != HAL_OK)
  {
    errorcode = HAL_FLASH_GetError();		//???????
	printf("errorcode %d", errorcode);
    Error_Handler();
  }
  __HAL_FLASH_DATA_CACHE_DISABLE();
  __HAL_FLASH_INSTRUCTION_CACHE_DISABLE();

  __HAL_FLASH_DATA_CACHE_RESET();
  __HAL_FLASH_INSTRUCTION_CACHE_RESET();

  __HAL_FLASH_INSTRUCTION_CACHE_ENABLE();
  __HAL_FLASH_DATA_CACHE_ENABLE();
	
	printf("HAL_OK\r\n");
	
  Address = FLASH_USER_START_ADDR;

  while (Address < FLASH_USER_END_ADDR)
  {
	p = (uint32_t *)&RAM_Buffer[i];
    if (HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD, Address, *p) == HAL_OK)	//FLASH??
    {
      Address = Address + 4;
	  i = i + 4;
    }
    else
    {
	  printf("Address-error\r\n");
      Error_Handler();
    }
  }
  HAL_FLASH_Lock(); 

  Address = FLASH_USER_START_ADDR;		//??
  MemoryProgramStatus = 0x0;
  printf("CHEAK\r\n");
  while (Address < FLASH_USER_END_ADDR)
  {
    data32 = *(__IO uint32_t*)Address;

    if (data32 != *(uint32_t*)RAM_Buffer)
    {
      MemoryProgramStatus++;
    }
    Address = Address + 4;
  }
	printf("CHEAK-finish\r\n");
	
	return HAL_OK;
}
static uint32_t GetSector(uint32_t Address)		//????
{
  uint32_t sector = 0;
  
  if((Address < ADDR_FLASH_SECTOR_1) && (Address >= ADDR_FLASH_SECTOR_0))
  {
    sector = FLASH_SECTOR_0;  
  }
  else if((Address < ADDR_FLASH_SECTOR_2) && (Address >= ADDR_FLASH_SECTOR_1))
  {
    sector = FLASH_SECTOR_1;  
  }
  else if((Address < ADDR_FLASH_SECTOR_3) && (Address >= ADDR_FLASH_SECTOR_2))
  {
    sector = FLASH_SECTOR_2;  
  }
  else if((Address < ADDR_FLASH_SECTOR_4) && (Address >= ADDR_FLASH_SECTOR_3))
  {
    sector = FLASH_SECTOR_3;  
  }
  else if((Address < ADDR_FLASH_SECTOR_5) && (Address >= ADDR_FLASH_SECTOR_4))
  {
    sector = FLASH_SECTOR_4;  
  }
  else if((Address < ADDR_FLASH_SECTOR_6) && (Address >= ADDR_FLASH_SECTOR_5))
  {
    sector = FLASH_SECTOR_5;  
  }
  else if((Address < ADDR_FLASH_SECTOR_7) && (Address >= ADDR_FLASH_SECTOR_6))
  {
    sector = FLASH_SECTOR_6;  
  }
  else if((Address < ADDR_FLASH_SECTOR_8) && (Address >= ADDR_FLASH_SECTOR_7))
  {
    sector = FLASH_SECTOR_7;  
  }
  else if((Address < ADDR_FLASH_SECTOR_9) && (Address >= ADDR_FLASH_SECTOR_8))
  {
    sector = FLASH_SECTOR_8;  
  }
  else if((Address < ADDR_FLASH_SECTOR_10) && (Address >= ADDR_FLASH_SECTOR_9))
  {
    sector = FLASH_SECTOR_9;  
  }
  else if((Address < ADDR_FLASH_SECTOR_11) && (Address >= ADDR_FLASH_SECTOR_10))
  {
    sector = FLASH_SECTOR_10;  
  }
  else /* (Address < FLASH_END_ADDR) && (Address >= ADDR_FLASH_SECTOR_11) */
  {
    sector = FLASH_SECTOR_11;
  }

  return sector;
}
void jumpToApp()
{
    if (((*(__IO uint32_t*)FLASH_USER_START_ADDR) & 0x2FFE0000 ) == 0x20000000)
    {
	  printf("ADDR == 0x20000000\r\n");
      JumpAddress = *(__IO uint32_t*) (FLASH_USER_START_ADDR + 4);
	  Jump_To_Application = (pFunction) JumpAddress;
	  __set_MSP(*(__IO uint32_t*) FLASH_USER_START_ADDR);
	  __HAL_UART_DISABLE(&huart1);				//??????
	  __HAL_RCC_USB_OTG_FS_CLK_DISABLE();
	  __HAL_UART_CLEAR_FLAG(&huart1, UART_FLAG_TC);
	  __HAL_UART_DISABLE_IT(&huart1, UART_IT_RXNE);
	  Jump_To_Application();
    }
	printf("ADDR != 0x20000000\r\n");
}
void UP_Data(void)
{
		while(t < 2010)
		{
			MX_USB_HOST_Process();
			HAL_Delay(1);
			if(SystemUpdateFlag == 0 && Appli_state == APPLICATION_READY)
			{
				printf("APPLICATION_READY\r\n");
				SystemUpdateFlag = 1;
				t = 2000;
				state = 1;
				res = f_mount(&USBHFatFS, (TCHAR const*)USBHPath, 0);
				if(res != FR_OK)
				{
					printf("U�̹���ʧ��  %d\r\n", res);
					Error_Handler();
				}
				else
				{
					printf("U�̹��سɹ�\r\n");
				}
				res = f_open(&USBHFile, filename, FA_READ);
				if(res != FR_OK)
				{
					printf("��U���ļ�ʧ��  %d\r\n", res);
					Error_Handler();
				}
				else
				{
					printf("��U���ļ��ɹ�\r\n");
				}
				res = f_read(&USBHFile, RAM_Buffer, sizeof(RAM_Buffer), (void *)&APP_Size);
				if(res != FR_OK)
				{
					printf("��ȡU���ļ�ʧ��  %d\r\n", res);
					Error_Handler();
				}
				else
				{
					printf("��ȡU���ļ��ɹ�\r\n");
				}	
				if((0<APP_Size) && (APP_Size<FLASH_USER_END_ADDR))
				{
					printf("FLASH_Erase\r\n");
					FLASH_Erase_Write();
					jumpToApp();
				}
				else
				{
					printf("APP_Size_Erase\r\n");
				}
				f_close(&USBHFile);
		//		FATFS_UnLinkDriver(USBHPath);		
			
			}
			else
			{
				printf("%d\r\n", t);		
				t++;
			}
			if(state == 0 && t > 2000)		//??2s ??U???
			{
				state = 1;
				printf("DISCONNECT\r\n");
				jumpToApp();
			}

		}
		
	
}
